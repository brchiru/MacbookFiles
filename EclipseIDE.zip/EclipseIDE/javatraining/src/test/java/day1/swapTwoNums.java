package day1;

import java.util.Scanner;

public class swapTwoNums extends BaseClass{

	public swapTwoNums(Scanner sc) {
		super(sc);
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int x,y;
		
		//Scanner sc = new Scanner(System.in);

		x = sc.nextInt();

		
		y = sc.nextInt();
		
		x = x+y;
		y = x-y;
		x = x-y;
		
		System.out.println("x: "+x+" y: "+y);

	}

}

package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObject.BlogPage;
import pageObject.HomePage;
import testBase.BaseClass;

@Test
public class TC01_Assert_isDisplayed extends BaseClass {
	
	
	public void findTextBlog() {
		
		try {
			HomePage hp = new HomePage(driver);
			
			hp.blogButtonClick();
			
			//Thread.sleep(5000);
			
			BlogPage bp = new BlogPage(driver);
			
			boolean targetURL = bp.blogURL();
			
			Assert.assertEquals(targetURL, true); 
			
			Assert.assertEquals(bp.blogHeadingText(),"BLOG ARCHIVE","Wrong Page");
		} 
		catch (Exception e)
		{
			Assert.fail();
		}
		
	}

}

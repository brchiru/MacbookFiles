package retrymech;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class RetryTestExample {

    WebDriver driver;

    @BeforeClass
    public void setUp() {
        //System.setProperty("webdriver.chrome.driver", "path_to_chromedriver");  // Set ChromeDriver path
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @Test(retryAnalyzer = RetryAnalyzer.class)
    public void testGoogleTitle() throws InterruptedException {
    	Thread.sleep(5000);
    	driver.get("https://www.google.com");
        String pageTitle = driver.getTitle();
        System.out.println("Page Title: " + pageTitle);

        // Intentionally failing the test to demonstrate retry mechanism
        Assert.assertEquals(pageTitle, "Wrong Title");
        
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
package DataProviderConcept;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProviderDemo {
	
	WebDriver driver;
	
	@BeforeClass
	void setup() 
	{
	
		driver = new EdgeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));

		
	}
	
	@Test(dataProvider="login")
	void testLogin(String uName, String Pwd) throws InterruptedException 
	{
		
		driver.get("https://petstore.octoperf.com/actions/Account.action?signonForm=");
		
		driver.manage().window().maximize();
		
		driver.findElement(By.name("username")).sendKeys(uName);
		driver.findElement(By.name("password")).clear();
		driver.findElement(By.name("password")).sendKeys(Pwd);
		
		driver.findElement(By.name("signon")).click();
		
		Thread.sleep(2000);
		
		boolean status = driver.findElement(By.xpath("//a[text()='Sign Out']")).isDisplayed();
		
		if(status == true)
		{
			driver.findElement(By.xpath("//a[text()='Sign Out']")).click();
			
			Assert.assertTrue(true);
		}
		else
		{
			Assert.fail();
		}
	
		
	}

	@AfterClass
	void tearDown() 
	{
		driver.quit(); 
	}
	
	
	
	
	// Creation of Data and Returning the test data
	@DataProvider(name="login", indices= {0,2,3}) //remove indices to run all 
	public Object[][] loginData() 
	{
		Object data[][] = 	{
								{"test001","test123"},
								{"test007","test123"},
								{"test002","test123"},
								{"test001","test123"},
							};
		return data;
	}
	
}

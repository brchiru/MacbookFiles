package pageObjects;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class JSAlertsPage extends BasePage{

	public JSAlertsPage(WebDriver driver) {super(driver);}

	@FindBy(xpath="//button[contains(text(),'JS Alert')]") WebElement btnClickForJSAlert;

	@FindBy(xpath="//button[contains(text(),'JS Confirm')]") WebElement btnClickForJSConfirm;

	@FindBy(xpath="//button[contains(text(),'JS Prompt')]") WebElement btnClickForJSPrompt;

	@FindBy(id="result") WebElement resultMsg;


	public String verifyResultText() {
		return resultMsg.getText();

	}


	public void clickJSAlertPop()
	{

		btnClickForJSAlert.click();
	}

	public void clickJSAlertConfirmPop()
	{
		btnClickForJSConfirm.click();
	}

	public void clickJSAlertPrompt()
	{
		btnClickForJSPrompt.click();
	}

	public void AlertAcceptButton() throws InterruptedException
	{
		Alert alert = driver.switchTo().alert();
		Thread.sleep(3000);
		alert.accept();
	}

	public void AlertDismissButton() throws InterruptedException
	{
		Alert alert = driver.switchTo().alert();
		Thread.sleep(3000);
		alert.dismiss();
	}

	public void AlertSendKeysText()
	{
		Alert alert = driver.switchTo().alert();
		alert.sendKeys("Hello");
	}


}

package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends BasePage
{
	public LoginPage(WebDriver driver) {super(driver);}
	
	@FindBy(name="username") WebElement uName_txtfield; 
	@FindBy(name="password") WebElement pWord_txtfield;
	@FindBy(name="signon") WebElement signon_button;
	@FindBy(xpath="//a[text()='Sign Out']") WebElement signoutBtn;
	
	@FindBy(xpath="//*[@id=\"Content\"]/ul/li/text()") WebElement loginErrorMsg;
	

	public void enterUName(String UName) 
	{
		uName_txtfield.sendKeys(UName);
	}
	
	public void enterPwd(String pWord) 
	{
		pWord_txtfield.clear();
		pWord_txtfield.sendKeys(pWord);
	}
	
	public void clickLoginButton() 
	{
		signon_button.click();
	}
	
	public void wrongLoginDisplayed() 
	{
		System.out.println(loginErrorMsg.getText());
//		return loginErrorMsg.getText() != null;
	}
	
	public boolean isSignOutLinkExist() 
	{
		boolean status = signoutBtn.isDisplayed();
		
		System.out.println("Signout Status is:"+status);
		
		return status;
	}
	
	public void clickSignOutButton() 
	{
		signoutBtn.click();
	}
}

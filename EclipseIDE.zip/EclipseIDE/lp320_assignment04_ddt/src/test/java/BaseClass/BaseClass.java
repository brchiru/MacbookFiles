package BaseClass;

import java.io.FileReader;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

import utilities.ExcelUtils;

public class BaseClass {
	
	public static WebDriver driver;
	public Properties p;
	 
	@BeforeClass
	public void setUp() throws IOException {
		driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		//driver.get("https://petstore.octoperf.com/actions/Account.action?signonForm=");
		
		FileReader rfile = new FileReader("./src/test/java/resources/config.properties");
		
		p = new Properties();
		
		p.load(rfile);
		
		driver.get(p.getProperty("url"));
		driver.manage().window().maximize();
	}

	@AfterClass
	public void tearDown() 
	{
		driver.quit();
	}
	
	@DataProvider(name="loginData")
	public Object[][] readExcelData() throws IOException
	{
		String filePath = "./testdata/LoginData.xlsx";
		String sheetName = "sheet1";
		return ExcelUtils.getTestData(filePath,sheetName);
	}
	
}

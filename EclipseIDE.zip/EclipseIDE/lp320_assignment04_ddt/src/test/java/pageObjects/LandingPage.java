package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LandingPage extends BasePage
{
	public LandingPage(WebDriver driver) {super(driver);}
	
	
	//@FindBy(xpath="//*[@id=\"WelcomeContent\"]") WebElement loginSuccess;
	
	@FindBy(xpath="//a[text()='Sign In']") WebElement signInButtonLNK;

	
	public void clickSignInBtn() 
	{
		signInButtonLNK.click();
	}
	
}

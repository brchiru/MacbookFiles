package extentReportClass;

import org.testng.ITestListener;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class NewExtentReport implements ITestListener{
	ExtentReports extent;
	ExtentTest test;

	@BeforeClass
	public void setup() {
		ExtentSparkReporter spark = new ExtentSparkReporter(
				"/Users/br_chiru/Documents/EclipseIDE/report/reports/ExtentReport.html");
		// Attach the SparkReporter to the ExtentReports instance
		extent = new ExtentReports();
		extent.attachReporter(spark);
	}

	@Test
	public void runTest() {
		test = extent.createTest("Sample Test");
		test.log(Status.PASS, "This is a sample test case.");
		System.out.println("Running testExample");
	}

	@AfterClass
	public void tearDown() {
		extent.flush(); // Important to write the report to file
	}

	public static void main(String[] args) {
		NewExtentReport report = new NewExtentReport();
		report.setup();
		report.runTest();
		report.tearDown();
	}
}
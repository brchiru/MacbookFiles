package day1;

import java.util.Scanner;

public class BaseClass {
	static Scanner sc = new Scanner(System.in);
	
	public BaseClass(Scanner sc) {
		BaseClass.sc = sc;
	}
}

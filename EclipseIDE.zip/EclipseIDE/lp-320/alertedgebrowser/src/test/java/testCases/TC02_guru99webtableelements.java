package testCases;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TC02_guru99webtableelements {

	WebDriver driver;

	@BeforeClass
	public void setUp()
	{
		driver = new EdgeDriver();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		driver.get("https://demo.guru99.com/test/web-table-element.php#");

		driver.manage().window().maximize();
	}

	@Test
	public void findCompanyNameOfMaxCurrentValue()
	{
		// Wait for the table to load
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//table[@class='dataTable']")));

        List<WebElement> rows = driver.findElements(By.xpath("//table[@class='dataTable']//tbody/tr"));


		System.out.println("No.Of Rows : "+rows.size());

		double maxPrice = 0.0;
		String maxPriceCompany ="";


		for(WebElement row :rows)
		{
			String companyName = row.findElement(By.xpath("td[1]")).getText();
			String currentCompanyPrice = row.findElement(By.xpath("td[4]")).getText();

			double costPrice = Double.parseDouble(currentCompanyPrice);
			//System.out.println("CompanyName:: "+companyName+" CurrentPrice is "+currentCompanyPrice+" ");

			if(costPrice > maxPrice)
			{
				maxPrice = costPrice;
				maxPriceCompany = companyName; 
			}
		}

		System.out.println("Company Name:: "+maxPriceCompany+" with  max Current market Price is "+maxPrice+" ");
	}

	@AfterClass
	public void tearDown() {
		driver.quit();
	}

}

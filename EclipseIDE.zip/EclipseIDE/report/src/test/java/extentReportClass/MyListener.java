package extentReportClass;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class MyListener implements ITestListener
{

	
	public void onStart(ITestContext context) 
	{
		    System.out.println("**** TEST **** Started...!");
	}
	  
	public void onTestStart(ITestResult result) 
	{
		 System.out.println("Test Class **** Started...!");	  
	}
	public void onTestSuccess(ITestResult result) {
		System.out.println("Test Class **** PASSED...!");	 
		  }
	public void onTestFailure(ITestResult result) {
		System.out.println("Test Class **** FAILED...!");	
		  }
	public void onTestSkipped(ITestResult result) {
		System.out.println("Test Class **** SKIPPED...!");	
		  }

	
}

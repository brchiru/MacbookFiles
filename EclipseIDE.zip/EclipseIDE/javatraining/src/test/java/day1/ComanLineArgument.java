package day1;

public class ComanLineArgument {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Number of arguments: " + args.length);
		if(args.length>0) {
			System.out.println("The Command Line "+" arguments are : ");
			
			for(String val:args)
				System.out.println(val);
		}
		else
			System.out.println("No command Line "+" arguments found");

	}

}

package extent.report;

import org.testng.Assert;
import org.testng.annotations.Test;



public class AppTest {

    @Test
    public void shouldAnswerWithTrue() {
        Assert.assertTrue(true);
    }
}

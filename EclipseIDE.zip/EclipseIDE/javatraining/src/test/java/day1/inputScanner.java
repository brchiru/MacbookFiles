package day1;

import java.util.Scanner;

public class inputScanner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.print("Enter First Name ::");
			String firstname = sc.nextLine();
			System.out.print("Enter Last Name ::");
			String lastname = sc.nextLine();
			
			System.out.println("Full Name Entered is : "+firstname+" "+lastname);
		}
		

	}

}

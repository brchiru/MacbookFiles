package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import BaseClass.BaseClass;
import pageObjects.JSAlertsPage;

@Test
public class TC01_AlertSwitchTo extends BaseClass {

	public void verifyAlertsPage()
	{

		try {

			Thread.sleep(5000);
			JSAlertsPage jsap = new JSAlertsPage(driver);

			/* JS Alert Pop Step 2 and 3 */

			jsap.clickJSAlertPop();

			jsap.AlertAcceptButton();

			Assert.assertEquals(jsap.verifyResultText(),"You successfully clicked an alert","!Wrong Message!");

			/* JS Alert Pop Step 4 and 5 */

			jsap.clickJSAlertConfirmPop();

			jsap.AlertAcceptButton();

			Assert.assertEquals(jsap.verifyResultText(),"You clicked: Ok","!Wrong Message!");

			/* JS Alert Pop Step 6 and 7 */

			jsap.clickJSAlertConfirmPop();

			jsap.AlertDismissButton();

			Assert.assertEquals(jsap.verifyResultText(),"You clicked: Cancel","!Wrong Message!");


			/* JS Alert Pop Step 8 and 9 */

			jsap.clickJSAlertPrompt();

			jsap.AlertSendKeysText();

			jsap.AlertAcceptButton();

			Assert.assertEquals(jsap.verifyResultText(),"You entered: Hello","!Wrong Message!");


			jsap.clickJSAlertPrompt();

			jsap.AlertSendKeysText();

			jsap.AlertDismissButton();

			Assert.assertEquals(jsap.verifyResultText(),"You entered: null","!Wrong Message!");
		}
		catch (InterruptedException e)
		{
			Assert.fail();
		}


	}



}

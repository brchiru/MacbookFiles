package day1;

class Employee {
    int id;
    String name;
    double salary;

    // Default constructor
    public Employee() {
        this.id = 0;
        this.name = "Unknown";
        this.salary = 0.0;
    }

    // Constructor with one parameter
    public Employee(int id) {
        this.id = id;
        this.name = "Unknown";
        this.salary = 0.0;
    }

    // Constructor with two parameters
    public Employee(int id, String name) {
        this.id = id;
        this.name = name;
        this.salary = 0.0;
    }

    // Constructor with three parameters
    public Employee(int id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    public void display() {
        System.out.println("ID: " + id + ", Name: " + name + ", Salary: " + salary);
    }
}

public class ConstructorOverloadingDemo {
    public static void main(String[] args) {
        Employee emp1 = new Employee();                       // Default constructor
        Employee emp2 = new Employee(101);                   // Constructor with 1 parameter
        Employee emp3 = new Employee(102, "Alice");          // Constructor with 2 parameters
        Employee emp4 = new Employee(103, "Bob", 50000.0);   // Constructor with 3 parameters

        emp1.display();
        emp2.display();
        emp3.display();
        emp4.display();
    }
}
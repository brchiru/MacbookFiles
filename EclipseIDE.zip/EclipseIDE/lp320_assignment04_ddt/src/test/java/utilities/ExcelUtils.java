package utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {

	public static Object[][] getTestData(String filePath, String sheetName) throws IOException
	{
		Object[][] data = null;
		
		
			FileInputStream fis = new FileInputStream(filePath);
			
			try (XSSFWorkbook wb = new XSSFWorkbook(fis)) 
			{
				XSSFSheet wsheet = wb.getSheet(sheetName);
				
				int rowCount = wsheet.getPhysicalNumberOfRows();
				
				int colCount = wsheet.getRow(0).getPhysicalNumberOfCells();
				
				data = new Object[rowCount-1][colCount];
				
				for(int r=1; r<rowCount; r++)
				{
					Row row = wsheet.getRow(r);
					for(int c=0; c<colCount; c++)
					{
						Cell cell = row.getCell(c);
						data[r-1][c] = cell.toString();
					}
				}
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		
		return data;
		
	}
}

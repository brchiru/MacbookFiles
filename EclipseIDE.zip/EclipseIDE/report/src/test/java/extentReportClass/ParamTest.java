package extentReportClass;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.annotations.AfterClass;

//@Listeners(DataProviderConcept.MyListener.class)
public class ParamTest {
	WebDriver driver; 
	
	@BeforeClass
	@Parameters({"browser"})
	void setup(String br) throws InterruptedException 
	{
		 
		switch(br.toLowerCase())
		{
			case "chrome" 	: driver = new ChromeDriver(); break;
			case "edge" 	: driver = new EdgeDriver(); break;
			case "safari"	: driver = new SafariDriver(); break;
			default 		: System.out.println("Wrong Browsers"); return;
		} 
		
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://petstore.octoperf.com/actions/Account.action?signonForm=");
		
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//*[@id=\"LogoContent\"]/a/img")).click();
		
	}

	@Test(priority=1)
	void testLogo()
	{
		boolean logoDisplayed = driver.findElement(By.xpath("//*[@id=\"LogoContent\"]/a/img")).isDisplayed();
		
		AssertJUnit.assertEquals(logoDisplayed, true);
		
	}
	
	@Test(priority=2) 
 	void testTitle()
	{
		AssertJUnit.assertEquals(driver.getTitle(), "JPetStore Demo");
		
	}
	
	@Test(priority=0)
	void testURL()
	{
		AssertJUnit.assertEquals("https://petstore.octoperf.com/actions/Catalog.action",driver.getCurrentUrl());
	}
	 
	
	@AfterClass
	void tearDown()
	{
		driver.quit();
	}
}

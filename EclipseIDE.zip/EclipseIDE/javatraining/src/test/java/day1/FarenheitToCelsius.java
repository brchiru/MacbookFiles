package day1;

import java.util.Scanner;

public class FarenheitToCelsius {

	public static void main(String[] args) {
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.print("Enter the Farenheit :: ");
			float fh = sc.nextFloat();
			
			float celsius;
			
			celsius = (5*(fh-32))/9;
			
			System.out.println("Clecusis is :: "+celsius);
		}
		
		
	}
}

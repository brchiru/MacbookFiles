package day1;

public class ExceptionHandle {

	public ExceptionHandle() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			int data = 100/0;
			
			System.out.println("Data ::"+data);
		} catch(ArithmeticException e) {
			System.out.println(e);
		}

	}

}

package day1;

public class printintvalue {
	
	public static void main(String[] args) {
	int number;
	
	int a = 5, b = 6;
	
	number = a + b;
	
	System.out.println("Addition of two number "+number);
}
}

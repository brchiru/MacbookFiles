// Final class definition
final class FinalClass {
    public void display() {
        System.out.println("This is a method in the final class.");
    }
}

// Attempting to inherit the final class will cause a compilation error
// class ChildClass extends FinalClass { // This will not compile
// }

public class a {
    public static void main(String[] args) {
        FinalClass finalClass = new FinalClass();
        finalClass.display();
    }
}
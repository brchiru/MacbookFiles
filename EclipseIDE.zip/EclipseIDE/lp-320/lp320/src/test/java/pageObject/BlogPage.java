package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class BlogPage extends BasePage{

	public BlogPage(WebDriver driver) {super(driver);}
	
	
	@FindBy(xpath="//strong[text()='Blog archive']") WebElement blogArchieveText;
	
	public boolean blogURL() 
	{
		
		try {
			
			Assert.assertEquals(driver.getCurrentUrl(), "https://demowebshop.tricentis.com/blog");
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return false;
		}
		
	}
	
	public String blogHeadingText() {
		
		return blogArchieveText.getText();
		
	}

}

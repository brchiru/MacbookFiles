package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import BaseClass.BaseClass;
import pageObjects.LandingPage;
import pageObjects.LoginPage;

@Test(dataProvider="loginData")
public class TC04_LoginValidation extends BaseClass
{
	public void verifyLogin(String username, String password) throws InterruptedException 
	{
		try 
		{
			LandingPage landpage = new LandingPage(driver);
			 
			landpage.clickSignInBtn(); 
			
			LoginPage lp = new LoginPage(driver);
			
			System.out.println("UserName is : "+username+" Password is : "+password);
			
			lp.enterUName(username);
			
			lp.enterPwd(password);
			Thread.sleep(1000);
			
			lp.clickLoginButton();
			
			Thread.sleep(3000);
			
			//Assert.assertEquals(lp.isSignOutLinkExist(), true, "Login Failed");
			
			if(lp.isSignOutLinkExist())
			{
				Assert.assertTrue(true);
				lp.clickSignOutButton();
			}
//			else
//			{
//				//lp.wrongLoginDisplayed();
////				Assert.assertFalse(false);
//				landpage.clickSignInBtn();
//			}
			
		} catch (Exception e) {
			Assert.fail();
		}
		
	}

}


/*
 * package ExcelDataProvider;
 * 
 * import java.io.IOException;
 * 
 * import org.testng.annotations.DataProvider;
 * 
 * import utilities.ExcelUtils;
 * 
 * public class ExcelDataProviderTest {
 * 
 * @DataProvider(name="loginData") public Object[][] readExcelData() { try {
 * return ExcelUtils.getTestData(); } catch (IOException e) { // TODO
 * Auto-generated catch block e.printStackTrace(); } }
 * 
 * }
 */

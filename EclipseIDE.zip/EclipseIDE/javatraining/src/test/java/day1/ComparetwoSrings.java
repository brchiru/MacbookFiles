package day1;

import java.util.Scanner;

public class ComparetwoSrings extends BaseClass{


	public ComparetwoSrings(Scanner sc) {
		super(sc);
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String FirstString;
		String SecondString;
		
		FirstString = sc.nextLine();
		SecondString = sc.nextLine();
		
		System.out.println("Two String are "+FirstString+" and "+SecondString);
		
		if(FirstString.compareTo(SecondString)==0)
			System.out.println("String are Equal");
		else
			System.out.println("String are UnEqual");
		
		
		

	}

}
